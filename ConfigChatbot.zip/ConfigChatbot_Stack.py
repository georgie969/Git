# Copyright © 2021, George Obi-Azubuike. All rights reserved.

import aws_cdk.aws_chatbot as chatbot
import aws_cdk.aws_config as config
import aws_cdk.aws_events_targets as targets
import aws_cdk.aws_sns as sns
from aws_cdk import core


class ConfigChatbotStack(core.Stack):
    def __init__(self, scope: core.Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # Topic to which compliance notification events will be published.
        # Please add your own SNS Topic in the double quotation marks.
        compliance_topic = sns.Topic(self, "")
        notifications_topics = [compliance_topic]

        # Config rules to be notified on compliance change. You can use any AWS Managed Config Rule for this purpose
        S3versionrule = config.ManagedRule(
            self,
            "s3-bucket-versioning-enabled",
            identifier=config.ManagedRuleIdentifiers.S3_BUCKET_VERSIONING_ENABLED,
        )
        S3versionrule.on_compliance_change("TopicEvent", target=targets.SnsTopic(compliance_topic))

        EC2volumerule = config.ManagedRule(
            self,
            "ec2-volume-inuse-check",
            identifier=config.ManagedRuleIdentifiers.EC2_VOLUME_INUSE_CHECK,
        )
        EC2volumerule.on_compliance_change("TopicEvent", target=targets.SnsTopic(compliance_topic))

        # Slack Channel Configuration with SNS topic for notifications on Compliance Change.
        # Please add your own Slack Configuration name, Slack workspace id and Slack channel id in the spaces provided
        slack_channel = chatbot.SlackChannelConfiguration(
            self,
            "MySlackChannel",
            slack_channel_configuration_name="",
            slack_workspace_id="",
            slack_channel_id="",
            notification_topics=[compliance_topic],
        )
